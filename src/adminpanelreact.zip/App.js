import './App.css';
import LoginForm from "./component/LoginForm"
import  Header  from "./component/Header";
function App() {
  return (
    <div className="App">
      <Header/>
      <LoginForm />

    </div>
  );
}

export default App;